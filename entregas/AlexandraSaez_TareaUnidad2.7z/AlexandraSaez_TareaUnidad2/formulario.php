<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="estilo.css">
        <title>formulario</title>
    </head>
<body>
<form name="formulario"  action="codificado.php" method="post">
<label>Frase: </label><input type="text" name="Mensaje" value="">
<label>Desplazamiento:</label> <input type="number" name="Desplazamiento"value="" >
<input type="submit" value="Enviar">
</body>
</html>

