<?php 
include 'funciones.php';

echo "<h1 align='center'>FELICIDADES</h1> <h2 align='center'>acaba de comprar</h2>"; 

mostrarCompra(); 
?>
<h2 align='center'>Gracias por su compra</h2> 
<h2>Vuelva pronto</h2> 
<a href="salir.php">TERMINAR</a>