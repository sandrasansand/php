<?php 
session_start();
session_destroy();
 ?>

 <html>
 <head>
 	<title>Sesión cerrada</title>
 </head>
 <body>
 <p>Gracias Por tu compra</p><br><br>

 <a href="index.php">Formulario de autentificación</a>
 </body>
 </html>